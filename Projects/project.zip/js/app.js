//Problem: it looks gross in mobile screens
//Solution: To hide the text links and swap them with a more appropiate navigation-select box

//Create a select and append to menu
var $select = $("<select></select>");
$("#menu").append($select);
//cycle over menu links
$("#menu a").each( function() {
  var $anchor = $(this);
  //create an option
  var $option = $("<option></option>");
  
  $option.val( $anchor.attr("href") );
  
  //options is the text of the link
  $option.text( $anchor.text() );
 
  //append option to select
  $select.append($option);
  
});
//   for the select box of href
  
//Create button to click to go to select location
var $button = $("<button>Go</button>");
$("#menu").append($button);
//bind click to btn
$button.click(function(){
  window.location = $select.val();
});

//go to select buttton
//modify CSS to hide links on small resolution, also hide select button on larger width
//deal with selected options depending on current page

